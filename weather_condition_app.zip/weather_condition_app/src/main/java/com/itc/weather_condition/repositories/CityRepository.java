package com.itc.weather_condition.repositories;

import com.itc.weather_condition.madel.City;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface CityRepository extends JpaRepository<City, Integer> {

}