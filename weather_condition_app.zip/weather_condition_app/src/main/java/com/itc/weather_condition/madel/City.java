package com.itc.weather_condition.madel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/*
 Product entity.
 */
@Entity
@Table(name="city_dtle")
public class City {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int snumber;
    
   
    private String cityId;
    
    @Column(name="city_name")
    private String cityName;
    private String countryCode;
	public City() {
		
	}
	public City(String cityId, String cityName, String countryCode) {
		super();
		this.cityId = cityId;
		this.cityName = cityName;
		this.countryCode = countryCode;
	}
	public int getSnumber() {
		return snumber;
	}
	public void setSnumber(int snumber) {
		this.snumber = snumber;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	@Override
	public String toString() {
		return "City [snumber=" + snumber + ", cityId=" + cityId + ", cityName=" + cityName + ", countryCode="
				+ countryCode + "]";
	}
	
    
    
	
    

    
}