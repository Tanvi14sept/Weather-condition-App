package com.itc.weather_condition.services;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.itc.weather_condition.madel.User;
import com.itc.weather_condition.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
