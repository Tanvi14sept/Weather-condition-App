package com.itc.weather_condition.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.itc.weather_condition.madel.City;
import com.itc.weather_condition.repositories.CityRepository;

@Controller
public class MainController {
	@Autowired
	private CityRepository cityRepository;
	
	
	
	@GetMapping("/login")
	public String login() {
		
		return "login";
	}
	
	@GetMapping("/")
	public String home(Model m) {
		
		List<City> list= (List<City>) cityRepository.findAll();
		m.addAttribute("all_cities",list);
		return "index";
	}
	@GetMapping("/load_form")
	public String loadForm() {
		return "add";
	
}
	@GetMapping("/edit_form/{id}")
	public String editForm(@PathVariable(value="id")int id,Model m) 
	{
		
		Optional<City> city=cityRepository.findById(id);
		City citY=city.get();
		m.addAttribute("city",citY);
		
		
		return "edit";
    }
	@PostMapping("/save_City")
	public String savaCity(@ModelAttribute City city,HttpSession session)
	{
		cityRepository.save(city);
		session.setAttribute("msg", "city added Sucessfully...");
		return "redirect:/load_form";
		
	}
	@PostMapping("/update_city")
	public String updateCity(@ModelAttribute City city,HttpSession session)
	{
		cityRepository.save(city);
		session.setAttribute("msg", "city added Sucessfully...");
		return "redirect:/load_form";
		
	}
	@GetMapping("/delete/{id}")
	public String  deleteCity(@PathVariable(value="id") int id, HttpSession session)
	{
		cityRepository.deleteById(id);
		session.setAttribute("msg", "city delete Sucessfully...");
		return "redirect/";
	}
}

